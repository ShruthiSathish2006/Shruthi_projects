var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["e37ef420-d7d5-4bd6-9656-e942d0d62d86","9ac58b09-b539-4b03-95de-75e5c2df0fa7","87013549-d280-4041-8d37-c14b91e0f619","357551df-788a-42cd-8f5b-a9f87b31b2f6"],"propsByKey":{"e37ef420-d7d5-4bd6-9656-e942d0d62d86":{"name":"bunny2_1","sourceUrl":"assets/api/v1/animation-library/oawSosuk0_qAhPe2SzaubBwXPH9RM73F/category_animals/bunny2.png","frameSize":{"x":152,"y":193},"frameCount":2,"looping":true,"frameDelay":10,"version":"oawSosuk0_qAhPe2SzaubBwXPH9RM73F","loadedFromSource":true,"saved":true,"sourceSize":{"x":304,"y":193},"rootRelativePath":"assets/api/v1/animation-library/oawSosuk0_qAhPe2SzaubBwXPH9RM73F/category_animals/bunny2.png"},"9ac58b09-b539-4b03-95de-75e5c2df0fa7":{"name":"park_view_1","sourceUrl":"assets/api/v1/animation-library/4gC7uWaaRI4aDyrncCFO_wY_67vYhr4C/category_backgrounds/park_view.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"4gC7uWaaRI4aDyrncCFO_wY_67vYhr4C","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/4gC7uWaaRI4aDyrncCFO_wY_67vYhr4C/category_backgrounds/park_view.png"},"87013549-d280-4041-8d37-c14b91e0f619":{"name":"carrot_1","sourceUrl":"assets/api/v1/animation-library/fCiFCbsTDOoiLsbStivUZ249XH0TOxIY/category_food/carrot.png","frameSize":{"x":78,"y":70},"frameCount":1,"looping":true,"frameDelay":2,"version":"fCiFCbsTDOoiLsbStivUZ249XH0TOxIY","loadedFromSource":true,"saved":true,"sourceSize":{"x":78,"y":70},"rootRelativePath":"assets/api/v1/animation-library/fCiFCbsTDOoiLsbStivUZ249XH0TOxIY/category_food/carrot.png"},"357551df-788a-42cd-8f5b-a9f87b31b2f6":{"name":"farm_land_1","sourceUrl":"assets/api/v1/animation-library/4FnSIFL33P0PH_C_DnKOse2QbZCdtaJJ/category_backgrounds/farm_land.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"4FnSIFL33P0PH_C_DnKOse2QbZCdtaJJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/4FnSIFL33P0PH_C_DnKOse2QbZCdtaJJ/category_backgrounds/farm_land.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var bg = createSprite(200,200,400,400);
bg.setAnimation("park_view_1");
var ground = createSprite(200,380,500,20);
ground.shapeColor = "green";
bg.scale = 1.5;
var bunny = createSprite(80,325,10,10);
bunny.setAnimation("bunny2_1");
bunny.scale = 0.5;
 var itemGroup = createGroup();
 
var count = 0;


function draw(){
 drawSprites()
 
spawnbird();

  
  

ground.x = ground.width/2;
 
 bg.velocityX = -5;

 ground.velocityX = -15;
 if (bg.x < 100){
  bg.x = bg.width/2; } 
  
if(keyDown("space")&&bunny.y>=320){
  bunny.velocityY = -10 ;
} 
 bunny.velocityY = bunny.velocityY + 0.8;
 console.log(bunny.y);
  
  
  bunny.collide(ground);
  
  
  if( bunny.isTouching(itemGroup)){
     itemGroup.destroyEach();
    count = count + 10;
}



fill("black");
  textFont("Times New Roman");
  textSize(15)
  
  text("Score:" + count,300,40); 
    
if (count % 50 == 0){
  itemGroup.setVelocityXEach(-15);
  ground.velocityX = -20;
}  
 


 

}



function spawnbird() {
  
  
  
  if(World.frameCount%40 === 0){
    var item=createSprite(400,400,40,10);
    item.setCollider("circle");
    item.scale=0.5;
    item.velocityX=-10;
    item.setAnimation("carrot_1");
    item.y=randomNumber(200,300);
    item.lifetime=-1;
    itemGroup.add(item);
  
  
  
    
  }}
  
  
  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
